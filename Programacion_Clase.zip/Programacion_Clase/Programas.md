===CODIGOS DE JAVA===

#1 HOLA MUNDO
el codigo es un programa basico , el cual muestra en pantalla "Hello Word".

public class HolaMundo {
  public static void main(String[] args) {
    System.out.println("Hello World");
  }
}


#2 Java Intro
el codigo crea la variable nombre = "Jhon" y muesta un saludo en pantalla "Hola, Jhon".

public class Java_Intro {
  public static void main(String[] args) {
    String name = "John";
    System.out.println("Hello " + name);
  }
}


#3 Get Started
Su unica funcion es mostrar el "Hello Word".

public class GetStarted {
  public static void main(String[] args) {
    System.out.println("Hello World");
  }
}


#4 Java Syntax
Misma funcion de mostrar "Hello World". 

public class Main {
  public static void main(String[] args) {
    System.out.println("Hello World");
  }
}


#4.1 Java Statements 
multiples sentencias.

System.out.println("Java is fun!");
System.out.println("Hello World!");
System.out.println("Have a good day!");
System.out.println("Learning Java is fun!");

#5.1 Java Output
Muestra una guia basica usando printn conn que muestra en pantalla con un salto de linea.

System.out.println("Hello World!");
System.out.println("I am learning Java.");
System.out.println("It is awesome!");